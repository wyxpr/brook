
const salt = 'brook-web';
const splitWord = '---YnJvb2std2Vi---';