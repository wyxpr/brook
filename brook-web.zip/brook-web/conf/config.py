#coding=utf-8
#。—————————————————————————————————————————— 
#。                                           
#。  config.py                               
#。                                           
#。 @Time    : 2019-03-31 08:02                
#。 @Author  : capton                        
#。 @Software: PyCharm                
#。 @Blog    : http://ccapton.cn              
#。 @Github  : https://github.com/ccapton     
#。 @Email   : chenweibin1125@foxmail.com     
#。__________________________________________
DEBUG = False

SQLALCHEMY_DATABASE_URI = 'sqlite:///db/brook-web.db'

SQLALCHEMY_TRACK_MODIFICATIONS = True
