#coding=utf-8
#。——————————————————————————————————————————
#。
#。  __init__.py.py
#。
#。 @Time    : 2019-03-31 07:51
#。 @Author  : capton
#。 @Software: PyCharm
#。 @Blog    : http://ccapton.cn
#。 @Github  : https://github.com/ccapton
#。 @Email   : chenweibin1125@foxmail.com
#。__________________________________________

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
